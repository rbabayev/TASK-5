﻿
#include <iostream>
#include <string>
#include <map>
#include <cassert>
using namespace std;

//Single

class StepIT
{
public:
    string _lesson;
    StepIT() {
        _lesson = nullptr;
    }
    StepIT(string lesson) {
        _lesson = lesson;
    }
    void setLesson(string lesson) { _lesson = lesson; }
    string getLesson() { return _lesson; }
    void print() {
        cout << "Lesson name : " << _lesson << endl;
    }
};

class Student : public StepIT
{
public:
    string _stuName;
    int _age;
    Student() {
        _age = 0;
        _stuName = nullptr;
    }
    Student(string name, int age) {
        _stuName = name;
        _age = age;
    }
    void setName(string name) { _stuName= name; }
    string getName() { return _stuName; }
    void setAge(int age) { _age = age; }
    int getAge() { return _age; }
    void printStuds() 
    {
        StepIT().print();
        cout << "Name : " << _stuName << endl;
        cout << "Age : " << _age << endl;
    }
};

//------------------------------------------------------------------------------

//Multilevel 
class Person {
public:
    int _year;
    string _name;
    string _surname;
    Person() {
        _year = 0;
        _name = nullptr;
        _surname = nullptr;
    }
    Person(int year, string name, string surname)
    {
        setYear(year);
        setName(name);
        setSurname(surname);
    }
    void setYear(int year) { _year = year; };
    int getYear(){ return _year; }
    void setName(string name) { _name = name; };
    string getName() { return _name; }
    void setSurname(string surname) { _surname = surname; };
    string getSurname() { return _surname; }

    void print() {
        cout << "---- SCHOOL ----" << endl;
        cout << "Year : " << _year << endl;
        cout << "Name : " << _name<< endl;
        cout << "Surname : " << _surname<< endl;

    }
};

class Teacher : public Person 
{
public :
    int classroom;
    void setClass(int _class) { classroom = _class; }
    int getClass() { return classroom; }
    void print_() {
        Person().print();
        cout << "Class num : " << classroom << endl;
    }
};

class Student : public Teacher 
{
public:
    int salary;
    void setSalary(int _salary) { salary = _salary; }
    int getSalary() { return salary; }
    void print_2() {
        Teacher().print_();
        cout << "Teacher salary : " << salary << endl;
    }
};

//------------------------------------------------------------------------------

//Multiply

class Team
{
public:
    string _teamNmae;
    Team() { _teamNmae = nullptr; }
    Team(string name) { _teamNmae = name; }
    void setName(string teamName) { _teamNmae = teamName; }
    string getTeamName() { return _teamNmae; }
    void print() { cout << "Club Name : " << _teamNmae << endl; }

};


class footballerNumber
{
public:
    int _number;
    void setNum(int number) { _number = number; }
    int getNumber() { return _number; }
    void printNum() { cout << "Footballer Number : " << _number << endl; }
};



class Footballer : public Team , public footballerNumber
{
public: 
    string _footballarName;
    void setPlayerName(string FName) { _footballarName = FName; }
    string getPlayerName() { return _footballarName; }
    void AllPrint() {
        Team().print();
        footballerNumber().printNum();
        cout << "Player name : " << _footballarName << endl;
    }

};


//------------------------------------------------------------------------------

//Hierarchical

class People {
public:
    string _name;
    int _year;
    People() {
        _name = nullptr;
        _year = 0;
    }
    People(string name, int year) {
        _name = name;
        _year = year;
    }
    void setName(string name) { _name = name; };
    string getName() { return _name; }
    void setYear(int year) { _year = year; }
    int getYear() { return _year; }

    void info() {
        cout << "Name : " << _name << endl;
        cout << "Year : " << _year << endl;
    }
};


class Woman : virtual public People {
public:
    void peopleInfo() {
        People().info();
        cout << "Gender : Woman" << endl;
    }
};


class Man : virtual public People {
public:
    void peopleInfo() {
        People().info();
        cout << "Gender : Man" << endl;
    }
};